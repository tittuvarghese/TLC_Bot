<?php
// Load composer
require __DIR__ . '/vendor/autoload.php';

$bot_api_key  = '473217584:AAGuIXUlKhgMsDeNWYJ2xnyhtDk3ZHYj-WY';
$bot_username = 'BondLiveBot';

$commands_paths = [
    __DIR__ . '/Commands/',
];


try {
    // Create Telegram API object
    $telegram = new Longman\TelegramBot\Telegram($bot_api_key, $bot_username);
    $telegram->addCommandsPaths($commands_paths);

    // Handle telegram webhook request
    $telegram->handle();
    //echo $telegram->$result;
} catch (Longman\TelegramBot\Exception\TelegramException $e) {
    // Silence is golden!
    // log telegram errors
    // echo $e->getMessage();
}

